import 'dart:async';
import 'dart:developer' as developer;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../api_services/CategoryDetailsAPI.dart';
import '../api_services/search_salon_s_api.dart';
import '../models/HomePageResponse.dart';
import '../models/SalonMain.dart';

class SearchFetchAPIData extends StatefulWidget {
  static const String routeName = '/search_fetch_api_data';
  const SearchFetchAPIData({super.key});
  @override
  _SearchFetchAPIDataState createState() => _SearchFetchAPIDataState();
}

class _SearchFetchAPIDataState extends State<SearchFetchAPIData> {

  final SearchSalonSApi _apiService = SearchSalonSApi();

  // final TextEditingController _searchController = TextEditingController();
  // String _searchType = 'Salon';
  // String _searchQuery = 'salon';
  // List<SalonMain> _items = [];
  // int _currentPage = 1;
  // bool _hasMore = true;
  // bool _isLoading = false;
  // late Future<dynamic> _searchDataFuture;
  // Timer? _debounce;

  @override
  void initState() {
    super.initState();
    //_searchDataFuture = _fetchData(page: _currentPage); // Initialize directly
    //_searchController.addListener(_onSearchChanged);

    //_apiService.searchSalons("salon");
    _apiService.searchService("hair");
    //_apiService.searchDeal("test");
  }



  // Future<SearchSalonResponseData?> _fetchData({required int page}) async {
  //   setState(() {
  //     _isLoading = true;
  //   });
  //   try {
  //     switch (_searchType) {
  //       case 'Salon':
  //         return await _apiService.searchSalons(_searchQuery, page: page);
  //       default:
  //         return null;
  //     }
  //   } finally {
  //     setState(() {
  //       _isLoading = false;
  //     });
  //   }
  // }

  // void _onSearchChanged() {
  //   if (_debounce?.isActive ?? false) _debounce!.cancel();
  //   _debounce = Timer(const Duration(milliseconds: 500), () {
  //     setState(() {
  //       _searchQuery = _searchController.text.trim();
  //       _currentPage = 1;
  //       _items.clear();
  //       _hasMore = true;
  //       _searchDataFuture = _fetchData(page: _currentPage);
  //     });
  //   });
  // }

  // void _onSearchTypeChanged(String? newType) {
  //   if (newType != null) {
  //     setState(() {
  //       _searchType = newType;
  //       _currentPage = 1;
  //       _items.clear();
  //       _hasMore = true;
  //       _searchDataFuture = _fetchData(page: _currentPage);
  //     });
  //   }
  // }

  // void _refreshData() {
  //   setState(() {
  //     _currentPage = 1;
  //     _items.clear();
  //     _hasMore = true;
  //     _searchDataFuture = _fetchData(page: _currentPage);
  //   });
  // }

  // void _loadMore() {
  //   if (!_hasMore || _isLoading) return;
  //   setState(() {
  //     _currentPage++;
  //     _searchDataFuture = _fetchData(page: _currentPage);
  //   });
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Search'),
        backgroundColor: Colors.blueAccent,
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: (){},
        child: const Icon(Icons.refresh),
        tooltip: 'Refresh Data',
        backgroundColor: Colors.blueAccent,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

          ],
        ),
      ),
    );
  }

  Widget _buildSalonCard(SalonMain salon) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            salon.image != null
                ? CircleAvatar(
              radius: 30,
              backgroundImage: NetworkImage(salon.image!),
              onBackgroundImageError: (error, stackTrace) {
                developer.log('Failed to load salon logo: ${salon.image}, error: $error');
              },
              child: salon.image == null ? const Icon(Icons.store) : null,
            )
                : const CircleAvatar(
              radius: 30,
              child: Icon(Icons.store),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    salon.name ?? '',
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    salon.address ?? '',
                    style: const TextStyle(fontSize: 14, color: Colors.grey),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Icon(Icons.star, color: Colors.amber, size: 16),
                      const SizedBox(width: 4),
                      Text(
                        '${salon.averageRating} (${salon.reviewCount} reviews)',
                        style: const TextStyle(fontSize: 14),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'For: ${salon.name?.toUpperCase()}',
                    style: const TextStyle(fontSize: 14, color: Colors.blueAccent),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

extension StringExtension on String {
  String capitalize() {
    return "${this[0].toUpperCase()}${substring(1).toLowerCase()}";
  }
}