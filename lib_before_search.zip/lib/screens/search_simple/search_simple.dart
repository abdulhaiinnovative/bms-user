import 'dart:ui';
import 'package:flutter/material.dart';

class SearchSimple extends StatefulWidget {
  static String routeName = "/search_simple";

  @override
  _SearchSimpleState createState() => _SearchSimpleState();
}

class _SearchSimpleState extends State<SearchSimple> {
  String searchQuery = "";
  String selectedSearchType = "Salon";
  String selectedSort = "Newest";
  List<String> searchTypes = ["Salon", "Services", "Coupon"];
  List<String> sortOptions = [
    "Price: High to Low",
    "Price: Low to High",
    "Title: A-Z",
    "Title: Z-A",
    "Newest",
    "Oldest",
    "Popular"
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Search"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            TextField(
              decoration: InputDecoration(
                hintText: "Search...",
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
              onChanged: (value) {
                setState(() {
                  searchQuery = value;
                });
              },
            ),
            SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: searchTypes.map((type) {
                return Expanded(
                  child: Container(
                    margin: EdgeInsets.fromLTRB(5, 2, 2, 5),
                    child: SizedBox(
                      width: double.infinity,
                      child: ChoiceChip(
                        label: Center( // Center text inside the button
                          child: Text(
                            type,
                            style: TextStyle(
                              color: selectedSearchType == type ? Colors.white : Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: 16
                            ),
                          ),
                        ),
                        selected: selectedSearchType == type,
                        selectedColor: Colors.pink,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10), // Adjust radius as needed
                        ),
                        onSelected: (selected) {
                          setState(() {
                            selectedSearchType = type;
                          });
                        },
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),


            SizedBox(height: 10),
            Wrap(
              spacing: 10,
              children: [
                FilterChip(
                  label: Text(
                    "Price Range",
                    style: TextStyle(color: Colors.pink),
                  ),
                  selectedColor: Colors.pink,
                  backgroundColor: Colors.grey[200],
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20), // Adjust radius as needed
                  ),
                  onSelected: (val) {},
                ),
                FilterChip(
                  label: Text(
                    "Location",
                    style: TextStyle(color: Colors.pink),
                  ),
                  selectedColor: Colors.pink,
                  backgroundColor: Colors.grey[200],
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20), // Adjust radius as needed
                  ),
                  onSelected: (val) {},
                ),
                FilterChip(
                  label: Text(
                    "Category",
                    style: TextStyle(color: Colors.pink),
                  ),
                  selectedColor: Colors.pink,
                  backgroundColor: Colors.grey[200],
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20), // Adjust radius as needed
                  ),
                  onSelected: (val) {},
                ),
              ],
            ),
            SizedBox(height: 10),
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20), // Adjust radius as needed
                boxShadow: [
                  BoxShadow(
                    color: Colors.pink.withOpacity(0.1), // Shadow color with transparency
                    spreadRadius: 12, // How much the shadow spreads
                    blurRadius: 8, // How soft the shadow is
                    offset: Offset(2, 4), // X and Y position of the shadow
                  ),
                ],
              ),

              padding: EdgeInsetsDirectional.symmetric(horizontal: 20, vertical: 5),
              margin: EdgeInsetsDirectional.symmetric(horizontal: 10, vertical: 10),
              child: DropdownButton<String>(
                value: selectedSort,
                isExpanded: true,
                items: sortOptions.map((option) {
                  return DropdownMenuItem<String>(
                    value: option,
                    child: Text(option),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    selectedSort = value!;
                  });
                },
              ),
            ),
            SizedBox(height: 20,),
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(40), // Adjust radius as needed
                ),
                child: Center(
                  child: Text("Search loading.."),
                ),
              ),


            ),
          ],
        ),
      ),
    );
  }
}
