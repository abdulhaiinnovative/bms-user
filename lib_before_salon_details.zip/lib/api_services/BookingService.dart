import 'dart:convert';
import 'dart:developer';
import 'package:app/utlis/UtilsExtra.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../models/home/Professional.dart';
import '../../models/HomePageResponse.dart';

class BookingService {
  Future<void> createBooking({
    required BuildContext context,
    required Map<Service, int>? cartItems,
    required DateTime? selectedDay,
    required String? selectedTime,
    required List<Professional> selectedProfessionals,
    required String? paymentMethod,
    required String bookingType, // "deal" or "appointment"
  }) async {
    // Log all relevant values
    log('BookingService - createBooking values:');
    log('  salon_id: 1');
    log('  profession_id: ${selectedProfessionals.isNotEmpty ? selectedProfessionals.map((p) => p.id ?? 0).toList() : [0]}');
    log('  time: ${selectedTime != null && selectedDay != null ? "$selectedTime, ${DateFormat('yyyy-MM-dd').format(selectedDay)}" : "Not selected"}');
    log('  payment_status: ${paymentMethod == 'Cash' ? true : false}');
    log('  total_price: ${cartItems?.entries.fold<double>(0, (sum, entry) => sum + (entry.key.price ?? 0) * entry.value) ?? 0}');
    log('  booking_type: $bookingType');
    if (bookingType == 'appointment' && cartItems != null) {
      log('  service_id: ${cartItems.keys.map((s) => s.id ?? 0).toList()}');
      log('  qty: ${cartItems.map((s, q) => MapEntry(s.id.toString(), q))}');
    } else if (bookingType == 'deal') {
      log('  deal_id: 1');
    }

    // Show loading dialog
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        content: Row(
          children: [
            CircularProgressIndicator(),
            SizedBox(width: 16),
            Text('Processing booking...'),
          ],
        ),
      ),
    );

    try {
      // Prepare the payload
      final Map<String, dynamic> payload = {
        "salon_id": 1,
        "profession_id": selectedProfessionals.isNotEmpty
            ? selectedProfessionals.map((p) => p.id ?? 0).toList()
            : [0],
        "time": selectedTime != null && selectedDay != null
            ? "$selectedTime, ${DateFormat('yyyy-MM-dd').format(selectedDay)}"
            : null,
        "payment_status": paymentMethod == 'Cash' ? true : false,
        "total_price": cartItems?.entries.fold<double>(
            0, (sum, entry) => sum + (entry.key.price ?? 0) * entry.value) ??
            0,
        "booking_type": bookingType,
      };

      // Add booking type specific fields
      if (bookingType == 'appointment' && cartItems != null) {
        payload["service_id"] = cartItems.keys
            .map((service) => service.id ?? 0)
            .toList();
        payload["qty"] = cartItems.map((service, qty) =>
            MapEntry(service.id?.toString() ?? '0', qty));
      } else if (bookingType == 'deal') {
        payload["deal_id"] = 1;
      }

      String s = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiYmExYmU1MjQ2ZGYzYmYzNGI3YmZmMzFhZGVjNzI0OTUxYWEyZjc4MGM2ZDY2NjkwNjJhYWYzNTlkNjk1Yjg3MGNhMzI2ZjJiNTIwOGYxMWYiLCJpYXQiOjE3NDc1MTA0NzMuODk0NDY0OTY5NjM1MDA5NzY1NjI1LCJuYmYiOjE3NDc1MTA0NzMuODk0NDY4MDY5MDc2NTM4MDg1OTM3NSwiZXhwIjoxNzc5MDQ2NDczLjg4NTg3MzA3OTI5OTkyNjc1NzgxMjUsInN1YiI6IjEiLCJzY29wZXMiOltdfQ.VqwwT11kodgN7-B6ojKjBNw40n3gFfP0bSpzMqbngA5HiVfK2vOATunpr0kSSjPMNq0vyXTGbmX2dYAvc2rlcRbdv8ICOF6GY0V9iSfr4dsfQ_0U-L-ohcYLviZjU8FIkdfh0dVJhiVmRywojEPbK0aK01UA2os58EzaafQNmxlZdYL0fPgLAxW4jWI4XDkaENNYytm9jGq392Y7rPHKgyy1FE6ajCoh-nErMebiNr-QtF-B6Gd253NZYTjWK1P8ANZ7NaSO-aC-aPJLnyjAjhjG2bAXtsdc8qEpJHzZ9exxVlxlmyXyKGaAuNzPqU8oDqrpGAeSqpDxjslvpBe0figStZnX3sDHnYZshTVuH5Q7hBTIl6F_dOQm0GLt2mYXpssn3aVysJOW9BpNGTIJjRNJxcYlatRUf-GPxjgv_IO_nAHAJtJgF5bkw9nS57wCCYw5o-IQznZyQumYLZkGsBHXire7S45eND9YfXZS4DpyygI52pIKOLwUngjfzSTcP3FJImHcOXZ-FC_0vmBbaOLrfif2c6mvR_JnwNzheEjgo4t7u8iCQ3Ns1zm1nNyX_S7enkd6cKbnE8LIjwVjfXcGxxdi5bjmNOS1TpkJdylT15vtydwpcMWLq9Cup3Lxbrv_e3lMYvjCLCdTLIm_GwW3f-0iWnDhX8fIyNRieCE';

      s = await UtilsExtra.getToken() ?? '';

      log('Token:: $s');


      final headers = {
        'Content-Type': 'application/json',
        'Authorization':
        'Bearer $s'
      };
      // Make the POST API call
      final response = await http.post(
        Uri.parse('https://bms.innovativewidget.com/api/create-booking'),


      headers: headers,
        body: jsonEncode(payload),
      );

      // Close loading dialog
      Navigator.pop(context);

      // Handle response
      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        if (responseData['status'] == true) {
          // Show success dialog
          await showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: Text('Success'),
              content: Text(
                  responseData['message'] ?? 'Booking created successfully!'),
              actions: [
                TextButton(
                  child: Text('OK'),
                  onPressed: () {
                    Navigator.pop(context);
                    // Optionally navigate back
                    Navigator.pop(context);
                  },
                ),
              ],
            ),
          );
        } else {
          // Show error dialog for unsuccessful status
          await showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: Text('Error'),
              content: Text(
                  responseData['message'] ?? 'Failed to create booking.'),
              actions: [
                TextButton(
                  child: Text('Close'),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
          );
        }
      } else {
        // Show error dialog for non-200 status code
        await showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text('Error'),
            content:
            Text('Failed to create booking. Status code: ${response.statusCode}'),
            actions: [
              TextButton(
                child: Text('Close'),
                onPressed: () => Navigator.pop(context),
              ),
            ],
          ),
        );
      }
    } catch (e) {
      // Close loading dialog
      Navigator.pop(context);

      // Show error dialog for network or other errors
      await showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Error'),
          content: Text('An error occurred: $e'),
          actions: [
            TextButton(
              child: Text('Close'),
              onPressed: () => Navigator.pop(context),
            ),
          ],
        ),
      );
      log('Error in BookingService.createBooking: $e');
    }
  }
}