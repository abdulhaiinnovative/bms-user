import 'dart:convert';
import 'dart:developer';
import 'package:http/http.dart' as http;
import '../../models/MyBookingResponse.dart';
import '../utlis/UtilsExtra.dart';


import 'dart:convert';
import 'dart:developer';
import 'package:http/http.dart' as http;
import '../../models/MyBookingResponse.dart';
import '../utlis/UtilsExtra.dart';

class MyBookingsAPI {
  Future<MyBookingResponse?> getBooking({int page = 1, String? url}) async {


    try {

      String? token = await UtilsExtra.getToken();
      if (token == null || token.isEmpty) {
        throw Exception('No valid token provided');
      }

      log('Token: $token');

      token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiYmExYmU1MjQ2ZGYzYmYzNGI3YmZmMzFhZGVjNzI0OTUxYWEyZjc4MGM2ZDY2NjkwNjJhYWYzNTlkNjk1Yjg3MGNhMzI2ZjJiNTIwOGYxMWYiLCJpYXQiOjE3NDc1MTA0NzMuODk0NDY0OTY5NjM1MDA5NzY1NjI1LCJuYmYiOjE3NDc1MTA0NzMuODk0NDY4MDY5MDc2NTM4MDg1OTM3NSwiZXhwIjoxNzc5MDQ2NDczLjg4NTg3MzA3OTI5OTkyNjc1NzgxMjUsInN1YiI6IjEiLCJzY29wZXMiOltdfQ.VqwwT11kodgN7-B6ojKjBNw40n3gFfP0bSpzMqbngA5HiVfK2vOATunpr0kSSjPMNq0vyXTGbmX2dYAvc2rlcRbdv8ICOF6GY0V9iSfr4dsfQ_0U-L-ohcYLviZjU8FIkdfh0dVJhiVmRywojEPbK0aK01UA2os58EzaafQNmxlZdYL0fPgLAxW4jWI4XDkaENNYytm9jGq392Y7rPHKgyy1FE6ajCoh-nErMebiNr-QtF-B6Gd253NZYTjWK1P8ANZ7NaSO-aC-aPJLnyjAjhjG2bAXtsdc8qEpJHzZ9exxVlxlmyXyKGaAuNzPqU8oDqrpGAeSqpDxjslvpBe0figStZnX3sDHnYZshTVuH5Q7hBTIl6F_dOQm0GLt2mYXpssn3aVysJOW9BpNGTIJjRNJxcYlatRUf-GPxjgv_IO_nAHAJtJgF5bkw9nS57wCCYw5o-IQznZyQumYLZkGsBHXire7S45eND9YfXZS4DpyygI52pIKOLwUngjfzSTcP3FJImHcOXZ-FC_0vmBbaOLrfif2c6mvR_JnwNzheEjgo4t7u8iCQ3Ns1zm1nNyX_S7enkd6cKbnE8LIjwVjfXcGxxdi5bjmNOS1TpkJdylT15vtydwpcMWLq9Cup3Lxbrv_e3lMYvjCLCdTLIm_GwW3f-0iWnDhX8fIyNRieCE';


      final headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      };

      // Use provided url (next_page_url) or construct default URL with page
      final requestUrl = url ?? 'https://bms.innovativewidget.com/api/appointments?page=$page';
      log('Request URL: $requestUrl');

      final response = await http.get(
        Uri.parse(requestUrl),
        headers: headers,
      );

      log('getBooking response: statusCode=${response.statusCode}, body=${response.body}');

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        log('Decoded JSON: $responseData');
        try {
          final bookingResponse = MyBookingResponse.fromJson(responseData as Map<String, dynamic>);
          if (bookingResponse.status == true) {
            return bookingResponse;
          } else {
            throw Exception(bookingResponse.message ?? 'Failed to load bookings');
          }
        } catch (e) {
          log('Parsing error: $e, StackTrace: ${StackTrace.current}');
          rethrow;
        }
      } else {
        throw Exception('Failed to fetch bookings: HTTP ${response.statusCode}');
      }
    } catch (e) {
      log('Error in MyBookingsAPI.getBooking: $e, StackTrace: ${StackTrace.current}');
      rethrow;
    }
  }
}