import 'dart:developer';

import 'package:app/constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter_calendar_carousel/flutter_calendar_carousel.dart';
import 'package:flutter_calendar_carousel/classes/event.dart';
import '../../models/home/Professional.dart';
import '../../models/home/ServiceData.dart';
import 'package:app/models/HomePageResponse.dart';

import 'CartSummarySection.dart';
import 'CustomAppBar.dart';
import 'select_time_screen.dart';

class SelectDateScreen extends StatefulWidget {
  static const String routeName = '/select-date';

  const SelectDateScreen({Key? key}) : super(key: key);

  @override
  _SelectDateScreenState createState() => _SelectDateScreenState();
}

class _SelectDateScreenState extends State<SelectDateScreen> {
  DateTime _currentDate = DateTime.now();
  DateTime? _selectedDay;
  List<DateTime> _availableDates = [];
  List<Professional> _selectedProfessionals = [];
  String? _salonName;
  String? _salonAddress;
  String? _salonImage;

  Map<dynamic, int>? _cartItems;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final arguments = ModalRoute.of(context)?.settings.arguments;
      if (arguments is Map) {
        _cartItems = arguments['cartItems'] as Map<dynamic, int>? ?? {};
        _salonName = arguments['salonName'] as String?;
        _salonAddress = arguments['salonAddress'] as String?;
        _salonImage = arguments['salonImage'] as String?;

        final selectedProfessionals = arguments['selectedProfessionals'] as Map<dynamic, String?>?;
        if (selectedProfessionals != null) {
          for (var entry in selectedProfessionals.entries) {
            // Only if it's a Service (not Deal)
            if (entry.key is Service) {
              final service = entry.key as Service;
              final professionalName = entry.value;
              if (professionalName != null && professionalName != 'Any' && service.professionals != null) {
                final professional = service.professionals!.firstWhere(
                      (p) => p.name == professionalName,
                  orElse: () => Professional(name: 'Unknown'),
                );
                if (professional.name != 'Unknown') {
                  _selectedProfessionals.add(professional);
                }
              }
            }
          }
        }
      } else {
        _selectedProfessionals = [];
        _salonName = null;
        _salonAddress = null;
        _cartItems = null;
      }

      setState(() {
        _availableDates = _calculateAvailableDates();
      });
    });
  }

  List<DateTime> _calculateAvailableDates() {
    final now = _currentDate;
    final endDate = DateTime.now().add(Duration(days: 60));
    List<DateTime> availableDates = [];

    if (_selectedProfessionals.isNotEmpty) {
      for (DateTime date = now; date.isBefore(endDate) || date.isAtSameMomentAs(endDate); date = date.add(const Duration(days: 1))) {
        bool isAvailable = true;
        for (var professional in _selectedProfessionals) {
          if (!_isProfessionalAvailableOnDate(professional, date)) {
            isAvailable = false;
            break;
          }
        }
        if (isAvailable) {
          availableDates.add(DateTime(date.year, date.month, date.day));
        }
      }
    } else {
      // No professionals selected (only deals or all Any)
      for (DateTime date = now; date.isBefore(endDate) || date.isAtSameMomentAs(endDate); date = date.add(const Duration(days: 1))) {
        availableDates.add(DateTime(date.year, date.month, date.day));
      }
    }

    return availableDates;
  }

  bool _isProfessionalAvailableOnDate(Professional professional, DateTime date) {
    final startDate = professional.start_date != null ? DateTime.parse(professional.start_date!) : null;
    final endDate = professional.end_date != null ? DateTime.parse(professional.end_date!) : null;
    if (startDate != null && date.isBefore(startDate)) return false;
    if (endDate != null && date.isAfter(endDate)) return false;

    switch (date.weekday) {
      case DateTime.monday:
        return professional.monday == 1;
      case DateTime.tuesday:
        return professional.tuesday == 1;
      case DateTime.wednesday:
        return professional.wednesday == 1;
      case DateTime.thursday:
        return professional.thursday == 1;
      case DateTime.friday:
        return professional.friday == 1;
      case DateTime.saturday:
        return professional.saturday == 1;
      case DateTime.sunday:
        return professional.sunday == 1;
      default:
        return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final eventList = EventList<EventInterface>(
      events: {
        for (var date in _availableDates)
          date: [
            Event(
              date: date,
              title: 'Available',
              icon: Container(
                decoration: const BoxDecoration(
                  color: Colors.green,
                  shape: BoxShape.circle,
                ),
                width: 8,
                height: 8,
              ),
            ),
          ],
      },
    );

    return Scaffold(
      appBar: CustomAppBar(salonName: _salonName, salonAddress: _salonAddress, salonImage: _salonImage),
      body: Column(
        children: [
          if (_salonAddress != null)
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                'Address: $_salonAddress',
                style: const TextStyle(fontSize: 14, fontStyle: FontStyle.italic),
              ),
            ),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
            child: CalendarCarousel<EventInterface>(
              todayBorderColor: Colors.blueAccent,
              todayButtonColor: Colors.blueAccent,
              selectedDayBorderColor: Colors.blue,
              selectedDayButtonColor: Colors.blue,
              minSelectedDate: _currentDate,
              maxSelectedDate: DateTime.now().add(Duration(days: 60)),
              onDayPressed: (DateTime date, List<EventInterface> events) {
                if (_availableDates.any((d) => d.year == date.year && d.month == date.month && d.day == date.day)) {
                  setState(() {
                    _selectedDay = date;
                    _currentDate = date;
                  });
                }
              },
              markedDatesMap: eventList,
              markedDateShowIcon: true,
              markedDateIconBuilder: (event) => event.getIcon() ?? Container(),
              selectedDateTime: _selectedDay,
              targetDateTime: _currentDate,
              weekendTextStyle: const TextStyle(color: Colors.black),
              thisMonthDayBorderColor: Colors.grey,
              height: 380.0,
              showHeader: true,
              showWeekDays: true,
              weekDayFormat: WeekdayFormat.short,
            ),
          ),
          if (_selectedDay != null)
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                'Selected Date: ${_selectedDay!.toString().split(' ')[0]}',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
          ElevatedButton(
            onPressed: _selectedDay != null
                ? () {
              Navigator.pushNamed(
                context,
                SelectTimeScreen.routeName,
                arguments: {
                  'cartItems': _cartItems,
                  'selectedDay': _selectedDay,
                  'selectedProfessionals': _selectedProfessionals,
                  'salonName': _salonName,
                  'salonAddress': _salonAddress,
                },
              );
            }
                : null,
            child: const Text('Confirm Date'),
          ),
        ],
      ),
    );
  }
}
