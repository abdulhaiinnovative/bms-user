import 'dart:developer';

import 'package:app/models/SalonServicesCategorizedResponse.dart';
import 'package:app/models/HomePageResponse.dart';
import 'package:app/screens/test_scroll/CustomAppBar.dart';
import 'package:app/utlis/UtilsExtra.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:remixicon/remixicon.dart';
// import 'package:app/screens/test_scroll/jewellery_repository.dart';
import '../../api_services/salon_services_categorized_api.dart';
import '../../constants.dart';
import '../../helper/CircularNetworkImage.dart';
import 'CartSummarySection.dart';
import 'SelectDateScreen.dart';


class SelectProfessionals extends StatefulWidget {
  static String routeName = "/select_professionals";

  const SelectProfessionals({Key? key}) : super(key: key);

  @override
  _SelectProfessionalsState createState() => _SelectProfessionalsState();
}

class _SelectProfessionalsState extends State<SelectProfessionals> {
  Map<dynamic, String?> selectedProfessionals = {};
  Map<dynamic, int>? cartItems;
  String? salonName;
  String? salonImage;
  String? salonAddress;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      final arguments = ModalRoute.of(context)?.settings.arguments;
      if (arguments != null && arguments is Map) {
        setState(() {
          cartItems = arguments['cartItems'] as Map<dynamic, int>? ?? {};
          salonName = arguments['salonName'] as String?;
          salonImage = arguments['salonImage'] as String?;
          salonAddress = arguments['salonAddress'] as String?;

          log('cartItems length: ${cartItems?.length ?? 0}');
          log('salonName: $salonName');
          log('salonImage: $salonImage');
          log('salonAddress: $salonAddress');

          // Initialize selectedProfessionals with cartItems
          cartItems?.forEach((service, _) {
            selectedProfessionals[service] = null;
          });
        });
      } else {
        log('No valid arguments passed to SelectProfessionals');
        setState(() {
          cartItems = {};
        });
      }
    });
  }

  Widget _buildProfessionalSelector(Service service) {
    // Create a list of professionals including "Any"
    List<String> professionals = ['Any'];
    if (service.professionals != null) {
      professionals.addAll(service.professionals!.map((p) => p.name ?? 'Unknown'));
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Text(
            service.name ?? 'Service',
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: professionals.map((professional) {
              bool isSelected = selectedProfessionals[service] == professional;
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: ChoiceChip(
                  label: Text(professional),
                  selected: isSelected,
                  selectedColor: kPrimaryDarkColor,
                  labelStyle: TextStyle(
                    color: isSelected ? Colors.white : Colors.black,
                  ),
                  onSelected: (selected) {
                    setState(() {
                      selectedProfessionals[service] = selected ? professional : null;
                    });
                  },
                ),
              );
            }).toList(),
          ),
        ),
        const Divider(),
      ],
    );
  }

  Widget _buildDealItem(dynamic deal) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            deal.name ?? 'Deal',
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const Divider(),
        ],
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    bool canProceed = selectedProfessionals.entries
        .where((entry) => entry.key is Service)
        .every((entry) => entry.value != null);

    return Scaffold(
      appBar: CustomAppBar(
        salonName: salonName,
        salonAddress: salonAddress,
        salonImage: salonImage,
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          Positioned.fill(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  if (cartItems == null || cartItems!.isEmpty)
                    const Padding(
                      padding: EdgeInsets.all(16.0),
                      child: Center(
                        child: Text(
                          'No services in cart. Please add services to continue.',
                          style: TextStyle(fontSize: 16, color: Colors.grey),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    )
                  else
                    ...cartItems!.keys.map((item) {
                      if (item is Service) {
                        return _buildProfessionalSelector(item);
                      } else {
                        return _buildDealItem(item);
                      }
                    }).toList(),
                  const SizedBox(height: 100),
                ],
              ),

              // child: Column(
              //   children: [
              //     if (cartItems == null || cartItems!.isEmpty)
              //       const Padding(
              //         padding: EdgeInsets.all(16.0),
              //         child: Center(
              //           child: Text(
              //             'No services in cart. Please add services to continue.',
              //             style: TextStyle(fontSize: 16, color: Colors.grey),
              //             textAlign: TextAlign.center,
              //           ),
              //         ),
              //       )
              //     else
              //       ...cartItems!.keys
              //           .where((item) => item is Service)
              //           .map((service) => _buildProfessionalSelector(service as Service))
              //           .toList(),
              //     const SizedBox(height: 100),
              //   ],
              // ),
            ),
          ),
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 10,
                    spreadRadius: 2,
                  ),
                ],
                borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
              ),
              child: CartSummarySection(
                totalItems: cartItems!.length,
                totalAmount: 0,
                buttonColor: canProceed ? kPrimaryDarkColor : Colors.grey,
                onContinue: () {
                  if (canProceed) {
                    Navigator.pushNamed(
                      context,
                      SelectDateScreen.routeName,
                      arguments: {
                        'selectedProfessionals': selectedProfessionals,
                        'cartItems': cartItems,
                        'salonName': salonName,
                        'salonImage': salonImage,
                        'salonAddress': salonAddress,
                      },
                    );
                  }
                },
              ),
            ),
          ),
        ],
      ),
    );
  }


// @override
  // Widget build(BuildContext context) {
  //   bool canProceed = selectedProfessionals.values.every((professional) => professional != null);
  //
  //   return Scaffold(
  //     appBar: CustomAppBar(salonName: salonName, salonAddress: salonAddress, salonImage: salonImage),
  //     body: Stack(
  //       fit: StackFit.expand, // Ensure Stack fills the entire screen
  //       children: [
  //         Positioned.fill(
  //           child: SingleChildScrollView(
  //             child: Column(
  //               children: [
  //                 if (cartItems == null || cartItems!.isEmpty)
  //                   const Padding(
  //                     padding: EdgeInsets.all(16.0),
  //                     child: Center(
  //                       child: Text(
  //                         'No services in cart. Please add services to continue.',
  //                         style: TextStyle(fontSize: 16, color: Colors.grey),
  //                         textAlign: TextAlign.center,
  //                       ),
  //                     ),
  //                   )
  //                 else
  //                   ...cartItems!.keys.map((service) => _buildProfessionalSelector(service)).toList(),
  //                 const SizedBox(height: 100), // Increased to ensure button doesn't overlap content
  //               ],
  //             ),
  //           ),
  //         ),
  //         Positioned(
  //           bottom: 0,
  //           left: 0,
  //           right: 0,
  //           child: Container(
  //             padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
  //             decoration: BoxDecoration(
  //               color: Colors.white,
  //               boxShadow: [
  //                 BoxShadow(
  //                   color: Colors.black12,
  //                   blurRadius: 10,
  //                   spreadRadius: 2,
  //                 ),
  //               ],
  //               borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
  //             ),
  //             child: CartSummarySection(
  //               totalItems: cartItems!.length,
  //               totalAmount: 0,
  //               buttonColor: kPrimaryDarkColor,
  //               onContinue: () {
  //                 if (cartItems!.isNotEmpty) {
  //                   Navigator.pushNamed(
  //                     context,
  //                     SelectDateScreen.routeName,
  //                     arguments: {
  //                       'selectedProfessionals': selectedProfessionals,
  //                       'cartItems': cartItems,
  //                       'salonName': salonName,
  //                       'salonImage': salonImage,
  //                       'salonAddress': salonAddress,
  //
  //                     },
  //                   );
  //                 }
  //               },
  //             ),
  //             // child: SafeArea(
  //             //   top: false, // Only apply SafeArea to bottom to avoid top padding
  //             //   child: SizedBox(
  //             //     width: double.infinity,
  //             //     child: ElevatedButton(
  //             //       onPressed: canProceed && cartItems != null && cartItems!.isNotEmpty && !_isLoading
  //             //           ? () async {
  //             //         setState(() {
  //             //           _isLoading = true;
  //             //         });
  //             //         log('Selected professionals: $selectedProfessionals');
  //             //         try {
  //             //
  //             //           log(' confirm selection: ');
  //             //           // TODO: Implement proceed action (e.g., API call or navigation)
  //             //           // Example:
  //             //           //await someApiCall(selectedProfessionals);
  //             //
  //             //
  //             //           log('selectedProfessionals.length:    ${selectedProfessionals.length}');
  //             //           log('selectedProfessionals.keys:    ${selectedProfessionals.keys}');
  //             //           log('selectedProfessionals.entries:    ${selectedProfessionals.entries}');
  //             //
  //             //
  //             //           log('cartItems.length:    ${cartItems?.length}');
  //             //           log('cartItems.keys:    ${cartItems?.keys}');
  //             //           log('cartItems.entries:    ${cartItems?.entries}');
  //             //
  //             //
  //             //
  //             //
  //             //
  //             //           Navigator.pushNamed(
  //             //             context,
  //             //             SelectDateScreen.routeName,
  //             //             arguments: {
  //             //               'selectedProfessionals': selectedProfessionals,
  //             //               'cartItems': cartItems,
  //             //               'salonName': salonName,
  //             //               'salonAddress': salonAddress,
  //             //             },
  //             //           );
  //             //
  //             //
  //             //         } catch (e) {
  //             //           log('Error during confirm selection: $e');
  //             //           ScaffoldMessenger.of(context).showSnackBar(
  //             //             SnackBar(content: Text('An error occurred: $e')),
  //             //           );
  //             //         } finally {
  //             //           setState(() {
  //             //             _isLoading = false;
  //             //           });
  //             //         }
  //             //       }
  //             //           : null,
  //             //       style: ElevatedButton.styleFrom(
  //             //         backgroundColor: kPrimaryColor,
  //             //         shape: RoundedRectangleBorder(
  //             //           borderRadius: BorderRadius.circular(8),
  //             //         ),
  //             //         padding: const EdgeInsets.symmetric(vertical: 12),
  //             //       ),
  //             //       child: _isLoading
  //             //           ? const SizedBox(
  //             //         height: 20,
  //             //         width: 20,
  //             //         child: CircularProgressIndicator(
  //             //           color: Colors.white,
  //             //           strokeWidth: 2,
  //             //         ),
  //             //       )
  //             //           : const Text(
  //             //         'Confirm Selection',
  //             //         style: TextStyle(
  //             //           color: Colors.white,
  //             //           fontWeight: FontWeight.bold,
  //             //           fontSize: 16,
  //             //         ),
  //             //       ),
  //             //     ),
  //             //   ),
  //             // ),
  //           ),
  //         ),
  //       ],
  //     ),
  //   );
  // }


}