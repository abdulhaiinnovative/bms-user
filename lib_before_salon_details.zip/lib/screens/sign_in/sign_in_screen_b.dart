import 'dart:developer' as developer;
import 'dart:developer';

import 'package:app/constants.dart';
// import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
// import 'package:google_sign_in/google_sign_in.dart';
import 'package:provider/provider.dart';

import '../../components/no_account_text.dart';
import '../../components/socal_card.dart';
import '../../models/CreateUserViewModel.dart';
import '../../models/create_user/CreateUserResponse.dart';
import '../../my_widget/CustomButton.dart';
import '../../my_widget/CustomButtonGoogle.dart';
import '../../utlis/DialogUtils.dart';
import '../../utlis/MainDialog.dart';
import '../../utlis/UtilsExtra.dart';
import '../init_screen.dart';
import 'components/sign_form.dart';
import 'package:app/models/create_user/User.dart';

class SignInScreenB extends StatelessWidget {
  static String routeName = "/sign_in_b";


  const SignInScreenB({super.key});

  @override
  Widget build(BuildContext context) {

    return ChangeNotifierProvider(
      create: (_) => CreateUserViewModel(), // Replace with your ViewModel class
      child: Consumer<CreateUserViewModel>(
        builder: (context, viewModel, _) {
          return Scaffold(
            backgroundColor: kScreenBg,
            body: Column(
              children: [
                Flexible(
                  flex: 5,
                  child: Container(
                    color: kScreenBg,
                    child: Column(
                      children: [
                        SizedBox(height: 50),
                        Row(
                          children: [
                            Spacer(),
                            TextButton(
                              onPressed: () {
                                // Navigator.pushReplacement(
                                //   context,
                                //   MaterialPageRoute(builder: (context) => DashboardScreen()),
                                // );
                              },
                              child: Text("Skip for now"),
                            ),
                          ],
                        ),
                        Image.asset(
                          'assets/images/splash_logo.png',
                          width: 230,
                          height: 150,
                        ),
                        Spacer(),
                        const Text(
                          'Last Minute Brought \nto Life',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 24,
                            color: kPrimaryColor,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        Spacer(),
                      ],
                    ),
                  ),
                ),
                Flexible(
                  flex: 7,
                  child: Container(
                    color: kScreenBg,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          child: const Text(
                            'Register',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 24,
                              color: Colors.black,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        SizedBox(height: 5),
                        Container(
                          child: Text(
                            'Already have an account? Login here',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.grey.shade900,
                              fontWeight: FontWeight.w300,
                            ),
                          ),
                        ),
                        SizedBox(height: 24),
                        CustomButtonGoogle(
                          text: 'Continue with Google',
                          color: Colors.white,
                          onPressed: () => handleGoogleSignIn(context),

                        ),
                        SizedBox(height: 10),
                        CustomButton(
                          text: 'Continue with Apple',
                          color: Colors.black,
                          onPressed: () {
                            // _signInWithApple(context);
                          },
                        ),
                        const Padding(
                          padding: EdgeInsets.only(left: 25, right: 25, top: 0),
                          child: Row(
                            children: [
                              Expanded(
                                child: Divider(
                                  color: Colors.grey,
                                  thickness: 1,
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.symmetric(horizontal: 18.0),
                                child: Text(
                                  "Or",
                                  style: TextStyle(color: Colors.grey),
                                ),
                              ),
                              Expanded(
                                child: Divider(
                                  color: Colors.grey,
                                  thickness: 1,
                                ),
                              ),
                            ],
                          ),
                        ),
                        CustomButton(
                          text: 'Sign in with email',
                          color: kPrimaryColor,
                          onPressed: () async {
                            log('signInWithGoogle....');
                            //DialogLoadingUtils.showLoadingDialog(context);
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );

  }


  Future<void> handleGoogleSignIn(BuildContext context) async {
    developer.log("googleSignIn..");
    try {
      final GoogleSignIn _googleSignIn = GoogleSignIn(
        //ios
        clientId: '87062363095-d2ak3lfdnbk9l2a4b83v4pjtu5tort17.apps.googleusercontent.com',
        // clientId: '87062363095-mrde6nmhi2d2v9ptrfotoqdpgu2a26pr.apps.googleusercontent.com',
        scopes: ['email', 'profile', 'openid'],
      );
      var result = await _googleSignIn.signIn();
      developer.log("====--- try");
      developer.log('result: $result');
      if (result != null) {
        DialogLoadingUtils.showLoadingDialog(context);
        CreateUserResponse? ss = await CreateUserViewModel.createUser(
          "google",
          result.id,
          result.id,
          result.email ?? '-',
          "1234",
          "-",
          result.displayName ?? '-',
          result.displayName?.split(' ')[0] ?? '-',
          result.displayName?.split(' ')[1] ?? '-',
          "-",
        );
        DialogLoadingUtils.dismissDialog(context);
        await UtilsExtra.saveUserDetails(ss?.data?.user);
        await UtilsExtra.saveToken(ss?.data?.accessToken ?? "-");
        String s = await UtilsExtra.getToken() ?? '';
        developer.log('Token:New: $s');
        final mUser = await UtilsExtra.getUserDetails();
        if (mUser != null) {
          developer.log('mUser User Name: ${mUser.name}');
          Navigator.pushNamed(context, InitScreen.routeName);
        } else {
          developer.log('No user details found.');
        }
      } else {
        developer.log('Sign-in canceled or failed.');
      }
    } catch (error) {
      developer.log("====-- error: $error ");
      DialogLoadingUtils.dismissDialog(context);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Sign-in failed: $error')),
      );
    }
  }


  //ios
  // Future<void> handleGoogleSignIn(BuildContext context) async {
  //   developer.log("googleSignIn..");
  //
  //   try {
  //     final GoogleSignIn _googleSignIn = GoogleSignIn(
  //       //ios
  //       clientId: '87062363095-d2ak3lfdnbk9l2a4b83v4pjtu5tort17.apps.googleusercontent.com',
  //       //android
  //       //clientId: '87062363095-mrde6nmhi2d2v9ptrfotoqdpgu2a26pr.apps.googleusercontent.com',
  //
  //       scopes: ['email', 'profile', 'openid'],
  //     );
  //     var result = await _googleSignIn.signIn();
  //
  //
  //     developer.log("====--- try");
  //     developer.log('result: $result');
  //
  //
  //     if (result != null) {
  //       // await _createUser(result);
  //
  //
  //       DialogLoadingUtils.showLoadingDialog(context);
  //
  //       CreateUserResponse?  ss = await CreateUserViewModel.createUser(
  //             "google",
  //           result.id,
  //           result.id,
  //           result.email ?? '-',
  //              "1234", //token
  //             "-",
  //           result.displayName ?? '-',
  //           result.displayName?.split(' ')[0] ?? '-',
  //           result.displayName?.split(' ')[1] ?? '-',
  //             "-"
  //       );
  //
  //       //await createUserOnServer(context, result.displayName ?? '', result.email);
  //
  //       developer.log("==userIsAlreadyRegisteredModel: ${result.id}");
  //       developer.log("==userIsAlreadyRegisteredModel: ${result.displayName}");
  //       developer.log("==userIsAlreadyRegisteredModel: ${result.email}");
  //       developer.log("==userIsAlreadyRegisteredModel: ${result.photoUrl}");
  //
  //       developer.log("==userIsAlreadyRegisteredModel: email:   ${ss?.data?.user?.email}");
  //       developer.log("==userIsAlreadyRegisteredModel: token:   ${ss?.data?.accessToken}");
  //
  //       DialogLoadingUtils.dismissDialog(context);
  //
  //       await UtilsExtra.saveUserDetails(ss?.data?.user);
  //       await UtilsExtra.saveToken(ss?.data?.accessToken ?? "-");
  //
  //       String s = await UtilsExtra.getToken() ?? '';
  //
  //       log('Token:New: $s');
  //
  //
  //
  //       final mUser = await UtilsExtra.getUserDetails();
  //
  //       developer.log('\n\n');
  //
  //       if (mUser != null) {
  //         developer.log('mUser User Name: ${mUser.name}');
  //
  //         Navigator.pushNamed(context, InitScreen.routeName);
  //       } else {
  //         developer.log('No user details found.');
  //       }
  //
  //
  //
  //
  //     }
  //   } catch (error) {
  //     developer.log("====-- error: $error ");
  //     developer.log('error: $error');
  //     DialogLoadingUtils.dismissDialog(context);
  //   }
  //
  //
  //
  // }


  // Future<String?> getFCMToken() async {
  //   FirebaseMessaging messaging = FirebaseMessaging.instance;
  //   String? token = await messaging.getToken();
  //   print("FCM Token: $token");
  //   return token;
  // }


}





