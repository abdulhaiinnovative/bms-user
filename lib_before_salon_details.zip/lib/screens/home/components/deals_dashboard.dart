import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:app/components/sale_percentage.dart';
import 'package:app/constants.dart';
import 'package:app/components/ratings.dart';
import 'package:app/models/HomePageResponse.dart';
import 'package:app/screens/products/products_screen.dart';
import '../../test_scroll/salon_category_and_services_list.dart';
import 'section_title.dart';

class DealsDashboard extends StatelessWidget {
  final List<DealSection> type4;

  const DealsDashboard({
    Key? key,
    required this.type4,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: type4.map((section) {
        return Container(
          height: 240,
          margin: const EdgeInsets.only(bottom: 15),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: SectionTitle(
                  title: section.heading,
                  press: () {},
                ),
              ),
              const SizedBox(height: 10),
              Expanded(
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: section.data.length,
                  itemBuilder: (BuildContext context, int index) {
                    final item = section.data[index];
                    return SpecialOfferCard(
                      title: '${item.name}' ?? 'No Title',
                      image: item.image ?? logo,
                      desc: item.name ?? '',
                      press: () {
                        //Navigator.pushNamed(context, ProductsScreen.routeName);
                        Navigator.pushNamed(context, SalonCategoryAndServicesList.routeName, arguments: item);
                        log('Tapped Deal: ${item.name}');
                        log('Tapped Deal:salon id   ${item.services?[0]?.salon?.id}');
                        log('Tapped Deal:name   ${item.services?[0]?.salon?.name}');
                        log('Tapped Deal:image   ${item.services?[0]?.salon?.image}');
                        log('Tapped Deal:address   ${item.services?[0]?.salon?.address}');


                      },
                    );
                  },
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }
}


class SpecialOfferCard extends StatelessWidget {
  const SpecialOfferCard({
    Key? key,
    required this.title,
    required this.image,
    required this.desc,
    required this.press,
  }) : super(key: key);

  final String title, image;
  final String desc;
  final GestureTapCallback press;

  @override
  Widget build(BuildContext context) {
    return Container(



      padding: const EdgeInsets.only(left: 10, top: 5, bottom: 5),

      child: GestureDetector(
        onTap: press, // Attach the press callback here
        child: Container(
          width: 320,
          height: 150,
          padding: EdgeInsets.symmetric(horizontal: 8, vertical: 10),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
            boxShadow: [
              BoxShadow(
                color: kShadow,
                blurRadius: 1,
                offset: Offset(0, 0),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
                overflow: TextOverflow.ellipsis,
              ),
              SizedBox(width: 5),
              Text(
                desc,
                style: const TextStyle(
                  color: kPrimaryColor,
                  fontSize: 14,
                ),
                overflow: TextOverflow.ellipsis,
              ),
              Text(
                '30 min - 1 hr',
                style: const TextStyle(
                  color: Colors.black,
        
                ),
                overflow: TextOverflow.ellipsis,
              ),
        
              SizedBox(height: 10),
              Row(
                children: [
                  Icon(
                    Icons.cut_rounded,
                    color: Colors.black38,
                    size: 20,
                  ),
                  SizedBox(width: 5),
                  Text(
                    'Hair Coloring & Highlights Hair',
                    style: const TextStyle(
                      color: Colors.black87,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
              Spacer(),
        
        
        
              Row(
                children: [
                  Text(
                    'Rs: 3000',
                    style: const TextStyle(
                        color: kPrice,
                        fontSize: 18,
                        fontWeight: FontWeight.bold
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
        
                  SizedBox(width: 15),
        
                  Text(
                    'Rs: 4500',
                    style: const TextStyle(
                      color: kBeforeDiscount,
                      fontSize: 14,
                      decoration: TextDecoration.lineThrough,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
        
        
        
                  Spacer(),
                  SalePercentage(sale: 18),
                ],
              ),
        
        
            ],
          ),
        ),
      ),
    );
  }
}
