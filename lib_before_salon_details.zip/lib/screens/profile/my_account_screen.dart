import 'dart:developer';
import 'package:app/screens/profile/components/account_boxes.dart';
import 'package:flutter/material.dart';

import '../../api_services/my_account_api.dart';
import '../../models/my_account_response.dart';
import '../profile/components/profile_menu.dart';
import '../profile/components/profile_pic.dart';
import '../video_player_screen.dart';

class MyAccountScreen extends StatefulWidget {
  static String routeName = "/my_account";

  const MyAccountScreen({super.key});

  @override
  State<MyAccountScreen> createState() => _MyAccountScreenState();
}

class _MyAccountScreenState extends State<MyAccountScreen> {
  UserData? userData;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    loadProfile();
  }

  Future<void> loadProfile() async {
    log('Fetching user profile...');
    final profileResponse = await MyAccountAPI().getMyAccount();

    if (profileResponse != null && profileResponse.response?.user != null) {
      setState(() {
        userData = profileResponse.response!.user!;
        isLoading = false;
      });
    } else {
      log('Failed to load user profile');
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("My Account"),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : userData != null
          ? SingleChildScrollView(
        padding: const EdgeInsets.symmetric(vertical: 20),
        child: Column(
          children: [
            const ProfilePic("assets/images/logo.png"),
            const SizedBox(height: 20),
            AccountBoxes(
              title: "Name",
              value: "${userData?.name ?? 'N/A'}",
              press: null,
            ),
            AccountBoxes(
              title: "Email",
              value: "${userData?.email ?? 'N/A'}",
              press: null,
            ),
            AccountBoxes(
              title: "Phone",
              value: "${userData?.phone ?? 'N/A'}",
              press: null,
            ),
            AccountBoxes(
              title: "Gender",
              value: "${userData?.gender ?? 'N/A'}",
              press: null,
            ),
            AccountBoxes(
              title: "DOB",
              value: "${userData?.dob ?? 'N/A'}",
              press: null,
            ),

            AccountBoxes(
              title: "Address",
              value: "${userData?.address ?? 'N/A'}",
              press: null,
            ),

            AccountBoxes(
              title: "Appointment",
              value: "${userData?.appointment ?? 'N/A'}",
              press: null,
            ),

            AccountBoxes(
              title: "Cancel Count",
              value: "${userData?.cancelCount ?? 'N/A'}",
              press: null,
            ),

            AccountBoxes(
              title: "Complete Status",
              value: "${userData?.completeStatus ?? 'N/A'}",
              press: null,
            ),



            // VideoPlayerWidget(
            //   videoUrl:
            //   'https://drive.google.com/uc?export=download&id=1g5p0Ip4w9WapNVgeL7f5m5CSYrXfpr5z',
            // ),
            //
            // VideoPlayerWidget(
            //   videoUrl:
            //   //''
            //   // 'https://drive.google.com/uc?export=download&id=1cy6MUaqg05wEI8cSt0DSWJ60abfodpCM',
            //   'https://drive.google.com/uc?export=download&id=1g5p0Ip4w9WapNVgeL7f5m5CSYrXfpr5z',
            //     // https://drive.google.com/file/d/1g5p0Ip4w9WapNVgeL7f5m5CSYrXfpr5z/view?usp=drive_link
            //   // 'https://drive.google.com/file/d/1g5p0Ip4w9WapNVgeL7f5m5CSYrXfpr5z/view?usp=sharing',
            //   //'https://studentaku-my.sharepoint.com/personal/rehama_iqbal_scholar_aku_edu/_layouts/15/stream.aspx?id=%2Fpersonal%2Frehama%5Fiqbal%5Fscholar%5Faku%5Fedu%2FDocuments%2F1%5FFinal%5FVIDEOSmHealthapp%2F1%2E%20Balanced%20Diet%5FMessage%201%2Emp4&referrer=StreamWebApp%2EWeb&referrerScenario=AddressBarCopied%2Eview%2E86eeb353%2D77a3%2D4af4%2D9606%2D01da981c837c'
            // ),

          ],
        ),
      )
          : const Center(child: Text("Failed to load profile")),
    );
  }
}
