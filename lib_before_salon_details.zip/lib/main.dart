import 'package:app/screens/search_final/search_provider_new.dart';
// import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:app/providers/SearchProvider.dart';
import 'package:app/screens/splash/splash_screen.dart';
import 'routes.dart';
import 'theme.dart';
import 'package:flutter/material.dart';



Future<void> main() async {

  WidgetsFlutterBinding.ensureInitialized();
  //Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  // await Firebase.initializeApp(
  //     options: FirebaseOptions(
  //       apiKey: "AIzaSyAMWOBzXQOa1G1rCW5sZITUr-Z4uHXQcU4", // paste your api key here /// lets recheck
  //       appId: "1:87062363095:ios:dfc8f26f5ac5d0ec9ce992", //paste your app id here///====
  //       messagingSenderId: "87062363095", //paste your messagingSenderId here /// firebase
  //       projectId: "bookmyspot-c8bdb", //paste your project id here////======
  //     )
  // );


  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => SearchProvider()),
        ChangeNotifierProvider(create: (context) => SearchProviderNew()),
      ],
      child: MyApp(),
    ),
  );
}




class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'The Flutter Way - Template',
      theme: AppTheme.lightTheme(context),
      initialRoute: SplashScreen.routeName,
      // initialRoute: SearchFetchAPIData.routeName,
      routes: routes,
    );
  }
}
